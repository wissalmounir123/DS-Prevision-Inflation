# Introduction

La question étudiée est la suivante : *le chômage et le taux directeur
aident-ils à prévoir l'inflation d'un an sur l'autre ?* La théorie
économique suggère un lien (courbe de Phillips pour le chômage,
politique monétaire pour le taux directeur), mais l'utilité de ces
variables pour *prévoir* est une question empirique, distincte de celle
de l'existence d'une relation.

Il s'agit d'un problème d'**apprentissage supervisé**, plus précisément
d'une **régression** sur **séries temporelles** : la cible est une
valeur réelle (l'inflation dans 12 mois) et chaque observation est liée
aux précédentes. Cela impose deux précautions par rapport à un problème
classique : un découpage *temporel* entre entraînement et test (un
découpage aléatoire laisserait le modèle « voir le futur »), et une
métrique d'erreur adaptée, ici le RMSE
$$\mathrm{RMSE}=\sqrt{\frac{1}{n}\sum_{i=1}^{n}(y_i-\hat y_i)^2},$$
exprimé en points de pourcentage d'inflation.

Le rapport décrit les données
(section [2](#sec:donnees){reference-type="ref"
reference="sec:donnees"}), la méthode
(section [3](#sec:methode){reference-type="ref"
reference="sec:methode"}), les résultats
(section [4](#sec:resultats){reference-type="ref"
reference="sec:resultats"}), l'importance des variables
(section [5](#sec:importance){reference-type="ref"
reference="sec:importance"}), puis les limites, en particulier le biais
d'anticipation (section [7](#sec:limites){reference-type="ref"
reference="sec:limites"}).

# Données et prétraitement {#sec:donnees}

## Sources

Trois séries mensuelles américaines ont été téléchargées depuis FRED
(Réserve fédérale de Saint-Louis) :

- `CPIAUCSL` : indice des prix à la consommation, désaisonnalisé ;

- `UNRATE` : taux de chômage (%) ;

- `FEDFUNDS` : taux des fonds fédéraux (%), le taux directeur effectif.

Le jeu brut compte 958 mois, de janvier 1947 à octobre 2026. Les séries
ne commencent pas à la même date (`CPIAUCSL` en 1947, `UNRATE` en 1948,
`FEDFUNDS` en juillet 1954) ; l'alignement par la date ramène
l'échantillon à la période commune
(figure [1](#fig:series){reference-type="ref" reference="fig:series"}).

<figure id="fig:series" data-latex-placement="!htbp">
<img src="./figures/series_brutes.png" style="width:62.0%" />
<figcaption>Séries brutes : indice des prix (<code>CPIAUCSL</code>),
taux de chômage (<code>UNRATE</code>) et taux directeur
(<code>FEDFUNDS</code>).</figcaption>
</figure>

## Construction des variables

1.  **Alignement** : seuls les mois où les trois séries existent sont
    conservés.

2.  **Inflation annuelle** :
    $\pi_t = 100\left(\dfrac{CPI_t}{CPI_{t-12}}-1\right)$. L'indice brut
    est trop dépendant du temps ; sa variation sur 12 mois est bien plus
    stable. Après alignement et calcul, il reste 854 observations
    (juillet 1955 à septembre 2026), représentées en
    figure [2](#fig:inflation){reference-type="ref"
    reference="fig:inflation"}.

3.  **Retards** : pour chacune des trois variables (inflation, chômage,
    taux), on utilise les valeurs à $t$, $t-1$, $t-3$, $t-6$ et $t-12$,
    soit 15 variables explicatives.

4.  **Cible** : $y_t=\pi_{t+12}$, l'inflation observée 12 mois plus
    tard. Cela laisse 830 observations utilisables, avec des origines de
    prévision de juillet 1956 à août 2025.

<figure id="fig:inflation" data-latex-placement="!htbp">
<img src="./figures/inflation_annuelle.png" style="width:78.0%" />
<figcaption>Inflation annuelle américaine (variation sur 12 mois de
<code>CPIAUCSL</code>). La série traverse des régimes très différents :
la forte inflation des années 1970 et du début des années 1980, la
longue période modérée qui suit, la déflation de 2009, puis le pic de
2022.</figcaption>
</figure>

# Méthode {#sec:methode}

## Découpage temporel

L'échantillon est découpé à une date de coupure fixée *a priori*
(décembre 2010). Une ligne d'origine $t$ a pour cible $\pi_{t+12}$ ;
pour qu'aucune cible d'entraînement n'appartienne à la période de test,
seules sont conservées en entraînement les lignes dont la *date de
cible* est antérieure ou égale à la coupure. Cela crée un trou
volontaire de 12 mois.

::: center
  Jeu             Observations       Origines de prévision
  -------------- -------------- -------------------------------
  Entraînement        642        juillet 1956 -- décembre 2009
  Test                176          janvier 2011 -- août 2025
:::

Pour choisir les hyperparamètres, nous utilisons une validation croisée
temporelle (`TimeSeriesSplit`) à 5 plis, avec le même trou de 12 mois :
chaque pli entraîne sur le passé et valide sur la période qui suit (le
dernier pli valide sur 2001--2009). Le jeu de test n'est jamais utilisé
pour entraîner ni pour régler.

## Modèles

- **Référence** : l'inflation dans 12 mois est prédite égale à
  l'inflation d'aujourd'hui. Tout modèle utile doit faire mieux.

- **Régression Ridge** : régression linéaire pénalisée par la norme L2,
  précédée d'une standardisation (réapprise sur chaque pli). Le
  paramètre $\alpha$ est choisi parmi 13 valeurs de $10^{-3}$ à
  $10^{3}$.

- **Gradient boosting** : arbres peu profonds ajoutés séquentiellement.
  Grille : 100 ou 300 arbres, taux d'apprentissage 0,03 ou 0,1,
  profondeur 2 ou 3.

Chaque modèle est entraîné sur deux jeux de variables : *inflation
seule* (5 retards de l'inflation) et *complet* (15 variables :
inflation, chômage et taux directeur). C'est la comparaison entre ces
deux jeux qui répond à la question posée.

Les hyperparamètres retenus sont $\alpha=100$ (Ridge, inflation seule),
$\alpha\approx 316$ (Ridge, complet), et, pour le boosting dans les deux
cas, 100 arbres, taux d'apprentissage 0,03 et profondeur 2. Ce sont des
valeurs de régularisation fortes (Ridge) et des modèles très simples
(boosting), ce qui indique que la validation temporelle privilégie la
prudence.

# Résultats {#sec:resultats}

## Comparaison des modèles

Le tableau [1](#tab:rmse){reference-type="ref" reference="tab:rmse"}
donne le RMSE de validation (moyenne sur les plis temporels, avec les
meilleurs hyperparamètres, donc légèrement optimiste), le RMSE sur
l'ensemble du test, puis sur deux sous-périodes définies par la *date de
la cible* : avant 2020, et 2020 et après (pandémie, reprise, forte
inflation de 2021--2022).

::: {#tab:rmse}
  ----------------------------- ----------------- ------------ ----------- ------------- ---------------
  Modèle                        Variables          Validation     Test      Test, cible    Test, cible
                                                                            avant 2020    2020 et après
  Référence (dernière valeur)   Inflation seule    **2,004**      2,066        1,076          2,828
  Ridge                         Inflation seule      2,401      **1,903**      1,208        **2,494**
  Gradient boosting             Inflation seule      2,899        2,334        1,235          3,186
  Ridge                         Complet              2,586        2,186        1,241          2,943
  Gradient boosting             Complet              3,069        2,362      **1,009**        3,324
  ----------------------------- ----------------- ------------ ----------- ------------- ---------------

  : RMSE à 12 mois, en points de pourcentage d'inflation (en gras : la
  plus faible valeur de chaque colonne). « Complet » désigne inflation,
  chômage et taux directeur.
:::

Le tableau [2](#tab:ecarts){reference-type="ref" reference="tab:ecarts"}
exprime les mêmes résultats en écart relatif du RMSE de test (positif =
moins bon).

::: {#tab:ecarts}
                                                          Ridge              Gradient boosting
  ---------------------------------------------- ------------------------ -----------------------
  Inflation seule, par rapport à la référence          $-7{,}9\,\%$            $+13{,}0\,\%$
  Complet, par rapport à la référence                  $+5{,}8\,\%$            $+14{,}3\,\%$
  **Complet, par rapport à l'inflation seule**    $\mathbf{+14{,}8\,\%}$   $\mathbf{+1{,}2\,\%}$

  : Écart relatif du RMSE de test (positif = RMSE plus élevé, donc moins
  bonne prévision). La dernière ligne mesure l'apport du chômage et du
  taux directeur.
:::

Quatre constats se dégagent.

1.  **Un seul modèle bat la référence sur l'ensemble du test** : Ridge
    avec l'inflation seule (1,903 contre 2,066, soit $-7{,}9\,\%$). Les
    trois autres modèles font moins bien que la simple persistance.

2.  **Le chômage et le taux directeur n'apportent pas de gain.** Pour
    Ridge, le RMSE passe de 1,903 à 2,186 quand on les ajoute
    ($+14{,}8\,\%$). Pour le boosting, il passe de 2,334 à 2,362 : une
    différence négligeable.

3.  **En validation, la référence est la meilleure** (2,004), devant
    tous les modèles appris. La période de validation (1965--2009)
    inclut les années 1970, où l'inflation change brutalement de régime.
    Les modèles appris sur le passé y généralisent mal.

4.  **Le résultat dépend de la période.** Avant 2020, le boosting
    complet obtient la plus faible erreur (1,009, soit $-6{,}2\,\%$ par
    rapport à la référence et $-18{,}3\,\%$ par rapport au boosting à
    inflation seule). À partir de 2020, il devient le moins bon (3,324).
    Les erreurs de toute la période 2020 et après sont environ deux à
    trois fois plus fortes que celles d'avant 2020.

## Les prévisions comparées à l'inflation observée

La figure [3](#fig:pred){reference-type="ref" reference="fig:pred"}
permet de comprendre ces chiffres. L'épisode de 2021--2023 domine
l'erreur : l'inflation passe d'environ 1,5 % au début de 2021 à 8--9 % à
la mi-2022, et aucun modèle ne l'anticipe à 12 mois. La référence
reproduit l'inflation avec un an de retard, ce qui produit de grosses
erreurs à la hausse comme à la baisse. Le gradient boosting prévoit
ensuite environ 10 % en 2023, alors que l'inflation observée recule vers
3--6 %. La régression Ridge, plus prudente, évite les plus fortes
erreurs. Cela suggère que son avantage vient de sa tendance à ramener
les prévisions vers une valeur moyenne après un choc, plutôt que d'une
information propre au chômage ou au taux directeur (hypothèse que le
présent travail ne teste pas directement).

<figure id="fig:pred" data-latex-placement="!htbp">
<img src="./figures/predictions_test.png" style="width:88.0%" />
<figcaption>Prévisions à 12 mois sur la période de test, placées à la
date prévue. Aucun modèle n’anticipe la hausse de
2021–2022.</figcaption>
</figure>

## Test de robustesse : délai de publication

Le modèle principal suppose que l'inflation, le chômage et le taux du
mois $t$ sont connus au moment de la prévision. L'indice des prix n'est
en réalité publié qu'environ deux semaines après la fin du mois. Nous
avons donc refait l'analyse en retirant le retard 0 (variables à $t-1$,
$t-3$, $t-6$, $t-12$ uniquement), la référence devenant « l'inflation du
mois précédent ».

::: {#tab:robustesse}
  Modèle (sans valeur courante)    RMSE de test
  ------------------------------- --------------
  Référence (inflation à $t-1$)     **2,158**
  Ridge (complet)                     2,469
  Gradient boosting (complet)         2,591

  : Robustesse au délai de publication.
:::

Dans cette configuration plus réaliste, la référence devient la
meilleure : aucun modèle appris ne la bat. Elle-même se dégrade
légèrement (2,158 contre 2,066), ce qui est attendu puisqu'elle s'appuie
sur une information plus ancienne. Le résultat renforce la conclusion
principale : le gain des modèles appris sur la persistance est fragile.

# Importance des variables {#sec:importance}

Trois mesures complémentaires ont été utilisées sur les modèles
complets.

## Coefficients de Ridge et importance interne du boosting

La figure [4](#fig:coef){reference-type="ref" reference="fig:coef"}
présente à gauche les coefficients de Ridge (variables standardisées,
donc comparables) et à droite l'importance interne du boosting.

<figure id="fig:coef" data-latex-placement="!htbp">
<img src="./figures/coef_ridge_importance_gb.png" style="width:92.0%" />
<figcaption>À gauche : coefficients standardisés de la régression Ridge
(<span class="math inline"><em>α</em> ≈ 316</span>). À droite :
importance interne (réduction d’impureté) du gradient
boosting.</figcaption>
</figure>

Pour Ridge, les coefficients les plus élevés portent sur l'inflation
récente (`infl_t`, `infl_t-1`, `infl_t-3`). Les coefficients du chômage
et du taux directeur ont des signes qui changent selon le retard (par
exemple `taux_t` positif et `taux_t-12` négatif, `chomage_t-12` positif
et `chomage_t` négatif). Ce schéma est typique de variables retardées
très corrélées entre elles : les coefficients de chaque retard ne
s'interprètent pas isolément. Pour le boosting, `infl_t` concentre
environ 70 % de l'importance ; `chomage_t` et `taux_t` pèsent chacun
environ 8 %. Cette importance est toutefois calculée sur l'entraînement
et ne dit pas si ces variables servent hors échantillon.

## Importance par permutation

Mélanger une variable dans le jeu de *test* et mesurer la hausse du RMSE
indique ce qu'elle apporte à la performance réellement obtenue. Une
hausse positive signifie que la variable est utile ; une hausse négative
signifie que le modèle fait *mieux* quand la variable est brouillée,
donc que ce qu'il a appris sur elle ne tient pas sur la période de test.

<figure id="fig:perm" data-latex-placement="!htbp">
<img src="./figures/permutation_variables.png" style="width:62.0%" />
<figcaption>Importance par permutation, variable par variable, gradient
boosting (jeu de test, 20 répétitions, barres : écart-type). Seule
<code>infl_t</code> présente une hausse nettement positive ; plusieurs
variables de chômage et de taux ont une importance négative ou
nulle.</figcaption>
</figure>

Les retards d'une même variable étant corrélés, le mélange d'un seul
retard sous-estime l'importance de la variable : les autres retards
portent la même information. Nous avons donc aussi mélangé *tous les
retards d'une famille à la fois*
(figure [6](#fig:groupes){reference-type="ref" reference="fig:groupes"}
et tableau [4](#tab:groupes){reference-type="ref"
reference="tab:groupes"}).

<figure id="fig:groupes" data-latex-placement="!htbp">
<img src="./figures/permutation_groupes.png" style="width:58.0%" />
<figcaption>Importance par famille de variables (permutation de groupe
sur le jeu de test).</figcaption>
</figure>

::: {#tab:groupes}
  Famille                   Ridge              Gradient boosting
  ---------------- ------------------------ ------------------------
  Inflation         $+0{,}242 \pm 0{,}079$   $+0{,}196 \pm 0{,}101$
  Chômage           $-0{,}110 \pm 0{,}033$   $-0{,}162 \pm 0{,}058$
  Taux directeur    $-0{,}084 \pm 0{,}011$   $-0{,}008 \pm 0{,}024$

  : Hausse moyenne du RMSE de test (point de pourcentage) $\pm$
  écart-type sur les répétitions, lorsque toute la famille est mélangée.
:::

## Lecture

- L'**inflation passée** est la seule famille dont le brouillage
  détériore nettement la prévision, pour les deux modèles.

- Le **chômage** a une importance négative pour les deux modèles, à plus
  de deux écarts-types de zéro (écart-type calculé sur les répétitions
  du mélange, pas une incertitude d'échantillonnage) : le brouiller
  *améliore* les prévisions de test.

- Le **taux directeur** a une importance négative pour Ridge. Pour le
  boosting, elle est indiscernable de zéro.

- Ces résultats sont cohérents avec le
  tableau [2](#tab:ecarts){reference-type="ref"
  reference="tab:ecarts"} : ajouter ces deux familles de variables
  dégrade ou ne change pas la prévision. Ils illustrent aussi l'écart
  entre l'importance *interne* (calculée à l'entraînement), qui attribue
  du poids à ces variables, et l'importance *hors échantillon*, qui n'en
  trouve pas d'utile.

- Aucune de ces mesures n'établit une causalité : une importance
  prédictive n'est pas un effet causal, et une absence d'importance sur
  un test n'exclut pas un lien économique réel.

# Réponse à la question

**Sur nos données et notre protocole, le chômage et le taux directeur
n'aident pas à prévoir l'inflation à 12 mois.** Le RMSE de test est plus
élevé avec ces variables qu'avec l'inflation passée seule (+14,8 % pour
Ridge, +1,2 % pour le boosting), et leur brouillage améliore les
prévisions au lieu de les détériorer.

Trois nuances empêchent d'aller plus loin.

- **Avant 2020**, le boosting complet est le meilleur modèle (1,009,
  contre 1,235 avec l'inflation seule). Il y a donc peut-être un signal
  dans cette période, que la rupture de 2020--2022 ne confirme pas. Nous
  n'avons pas testé la significativité de cet écart.

- **Le gain de Ridge sur la référence (7,9 %) est modeste** et disparaît
  dans le test de robustesse au délai de publication. Il ne suffit pas à
  conclure que les modèles appris prévoient mieux que la persistance.

- **Un seul découpage a été évalué.** Les résultats pourraient changer
  avec une autre date de coupure.

# Limites {#sec:limites}

## Biais d'anticipation (*look-ahead bias*)

C'est la limite la plus importante. Les valeurs téléchargées
*aujourd'hui* ne sont pas celles qui existaient *à l'époque* où chaque
prévision aurait dû être faite. Les organismes statistiques révisent
leurs séries après publication :

- l'indice des prix désaisonnalisé (`CPIAUCSL`) voit ses facteurs
  saisonniers réestimés chaque année, ce qui modifie ses valeurs des
  dernières années ;

- le taux de chômage (`UNRATE`) est lui aussi révisé, à cause de la
  réestimation annuelle de ses facteurs saisonniers ;

- le taux directeur effectif (`FEDFUNDS`) est une moyenne observée, très
  peu révisée.

Notre modèle est donc évalué avec des données « nettoyées » qu'un
prévisionniste n'aurait pas eues en temps réel : de l'information
postérieure à la date de prévision s'infiltre dans les variables
explicatives. En général, ce biais rend les performances mesurées *trop
optimistes*, surtout pour les variables révisées (indice des prix,
chômage).

L'effet n'a pas été mesuré dans ce travail. On peut toutefois noter
qu'il n'est pas de nature à renforcer nos conclusions négatives : des
données en temps réel, plus bruitées, rendraient plutôt les modèles
appris moins performants, pas plus performants. Cette lecture reste une
hypothèse. La solution rigoureuse consiste à utiliser des données
*vintage*, c'est-à-dire les versions successives de chaque série telles
que publiées à chaque date (base ALFRED, de la Réserve fédérale de
Saint-Louis), et à ne fournir au modèle, à chaque date, que la version
alors disponible.

## Autres limites

- **Délai de publication.** Le test de robustesse
  (tableau [3](#tab:robustesse){reference-type="ref"
  reference="tab:robustesse"}) retire la valeur du mois courant, mais il
  ne reproduit pas exactement le calendrier de publication de chaque
  série.

- **Mois manquant dans les données.** Après alignement, on obtient 854
  observations alors que la période 1955--2026 en compterait 855 sans
  lacune ; les décomptes de valeurs manquantes des séries brutes
  indiquent qu'un mois intérieur est absent des séries `CPIAUCSL` et
  `UNRATE` (très probablement octobre 2025, mois sans publication de ces
  deux séries). Ce mois a été supprimé avant le calcul des décalages,
  qui s'effectuent par lignes. Pour une dizaine d'observations de test
  situées en fin de période, la cible correspond donc à un horizon de 13
  mois et non de 12. L'effet sur le RMSE est vraisemblablement faible
  (environ 6 % des observations de test), mais il n'a pas été quantifié.

- **Changements de régime.** La relation entre chômage, taux et
  inflation n'est pas stable (années 1970--1980, crise de 2008,
  pandémie, choc de 2021--2022). Les mauvaises performances en
  validation et après 2020 vont dans ce sens.

- **Un seul découpage, sans test statistique.** Aucun intervalle de
  confiance n'accompagne les RMSE. Avec 176 observations mensuelles très
  dépendantes entre elles, l'incertitude réelle est plus grande que ne
  le suggèrent les chiffres, et un écart de 8 % peut ne pas être
  significatif.

- **Variables corrélées et causalité.** Les retards d'une même variable
  sont très corrélés, et la banque centrale *réagit* à l'inflation : le
  taux directeur n'est pas exogène. Toute lecture causale des
  coefficients est donc fragile.

- **Un seul pays.** Les conclusions valent pour les États-Unis sur cette
  période.

# Conclusion

Sur les données FRED de 1955 à 2026, le chômage et le taux directeur
n'améliorent pas la prévision de l'inflation à 12 mois : avec ces
variables, l'erreur de test est plus élevée qu'avec l'inflation passée
seule, et l'importance par permutation leur attribue une valeur nulle ou
négative hors échantillon. Le seul modèle qui bat la référence est une
régression Ridge sur l'inflation seule, avec un gain modeste (8 %) et
fragile. L'erreur est dominée par l'épisode de 2021--2023, qu'aucun
modèle n'anticipe.

Ces résultats doivent être lus avec prudence : ils reposent sur des
données révisées (biais d'anticipation), sur un seul découpage temporel
et sur des séries qui changent de régime. Les prolongements les plus
utiles seraient d'utiliser des données *vintage* ALFRED, de faire varier
la date de coupure, d'ajouter des références plus exigeantes (moyenne
mobile de l'inflation, modèle autorégressif) et d'évaluer d'autres
horizons de prévision.

# Annexes {#annexes .unnumbered}

## A. Sources des données {#a.-sources-des-données .unnumbered}

Toutes les séries proviennent de la base FRED de la Réserve fédérale de
Saint-Louis (données américaines, fréquence mensuelle, téléchargées en
novembre 2026) :

- `CPIAUCSL` : <https://fred.stlouisfed.org/series/CPIAUCSL>

- `UNRATE` : <https://fred.stlouisfed.org/series/UNRATE>

- `FEDFUNDS` : <https://fred.stlouisfed.org/series/FEDFUNDS>

- ALFRED (versions successives des séries, pour les données *vintage*) :
  <https://alfred.stlouisfed.org>
